"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.manifest = void 0;
const netflixMirror_1 = require("../src/providers/netflixMirror");
exports.manifest = {
    netflixMirror: netflixMirror_1.netflixMirror
};
