"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.headers = void 0;
exports.headers = {
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-US,en;q=0.9',
    Connection: 'keep-alive',
    Cookie: 'HstCfa1685644=1728441808009; HstCla1685644=1729247141920; HstCmu1685644=1728441808009; HstPn1685644=4; HstPt1685644=7; HstCnv1685644=2; HstCns1685644=3; c_ref_1685644=https%3A%2F%2Fhimanshu8443.github.io%2F; __dtsu=6D0017284418145F3C5A94EBFCEC8BEE; HstCfa1188575=1728441827609; HstCla1188575=1729247144805; HstCmu1188575=1728441827609; HstPn1188575=1; HstPt1188575=5; HstCnv1188575=2; HstCns1188575=4; t_hash=3c1fd026be170294f6f5e9a9da9dcc82%3A%3A1728463347%3A%3Anv; SE80186863=81639536; recentplay=SE80186863; 81639536=1921%3A3150; addhash=a7f59781a3a69094131eddd440053a19; t_hash_t=86d54bfef842fe9f45ae5da4bb13cc1a%3A%3Ad7a6cab957bdbf4db18294e43b709e47%3A%3A1729247130%3A%3Anv',
    Host: 'iosmirror.cc',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 14; sdk_gphone64_x86_64 Build/UE1A.230829.036.A2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.136 Mobile Safari/537.36 /OS.Gatu v1.0',
    'X-Requested-With': 'com.example.netflixmirror',
};
