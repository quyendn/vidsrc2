"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nfGenresList = exports.nfCatalog = void 0;
exports.nfCatalog = [
    {
        title: 'Home',
        filter: '/home?app=1',
    },
    {
        title: 'Series',
        filter: '/series?app=1',
    },
    {
        title: 'Movies',
        filter: '/movies?app=1',
    },
];
exports.nfGenresList = [];
